<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>body_CURA Healthcare                       _fb9a78</name>
   <tag></tag>
   <elementGuidId>289c83f0-ec1b-467e-acbb-d0476a429d5f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>body</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//body</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;CURA Healthcare Home Login CURA Healthcare Service We Care About Your Health Mak&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>body</value>
      <webElementGuid>08ff368a-7e60-497a-bb7b-b7584ed70ee0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            Login
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Login
                Please login to make appointment.
                            
            
                
                    
                        
                            Demo account
                            
                                
                                  
                                  
                                
                            
                        
                        
                            
                                
                                  
                                  
                                
                            
                        
                    
                    
                        Username
                        
                            
                        
                    
                    
                        Password
                        
                            
                        
                    
                    
                        
                            Login
                        
                    
                
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










</value>
      <webElementGuid>4fa42fe7-7b66-421f-8f30-fd1ed5059a4c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]</value>
      <webElementGuid>d6e64f8f-b088-4bcd-8cd7-4a9b5521b468</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//body</value>
      <webElementGuid>c7b952df-8ae9-4535-b645-f3e6c752d428</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//body[(text() = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            Login
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Login
                Please login to make appointment.
                            
            
                
                    
                        
                            Demo account
                            
                                
                                  
                                  
                                
                            
                        
                        
                            
                                
                                  
                                  
                                
                            
                        
                    
                    
                        Username
                        
                            
                        
                    
                    
                        Password
                        
                            
                        
                    
                    
                        
                            Login
                        
                    
                
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










' or . = '



    
        
        
            CURA Healthcare
        
        
            Home
        
                
            Login
        
            




    
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    



    
        
            
                Login
                Please login to make appointment.
                            
            
                
                    
                        
                            Demo account
                            
                                
                                  
                                  
                                
                            
                        
                        
                            
                                
                                  
                                  
                                
                            
                        
                    
                    
                        Username
                        
                            
                        
                    
                    
                        Password
                        
                            
                        
                    
                    
                        
                            Login
                        
                    
                
            
        
    




    
        
            
                CURA Healthcare Service
                
                Atlanta 550 Pharr Road NE Suite 525Atlanta, GA 30305
                
                     (678) 813-1KMS
                     info@katalon.com
                    
                
                
                
                    
                        
                    
                    
                        
                    
                    
                        
                    
                
                
                Copyright © CURA Healthcare Service 2024
            
        
    
    










')]</value>
      <webElementGuid>c143e6db-a888-4751-ac81-68aa3c18c5a3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
